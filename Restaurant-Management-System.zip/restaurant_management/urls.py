from django.contrib import admin
from django.urls import path
from core.views import*

urlpatterns = [
    path('admin/', admin.site.urls),

    path('', home, name='home'),
    path('menu/', menu, name='menu'),
    path('reservation/', reservation, name='reservation'),
    path('login/', login_view, name='login'),
    path('register/', register, name='register'),
    path('cart/', cart, name='cart'),
    path('staff/dashboard/', staff_dashboard, name='staff_dashboard'),
    path('admin-panel/dashboard/', admin_dashboard, name='admin_dashboard'),
]