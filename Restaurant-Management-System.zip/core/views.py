from django.shortcuts import render


def home(request):
    return render(request, 'home.html')


def menu(request):
    return render(request, 'menu.html')


def reservation(request):
    return render(request, 'reservation.html')

def login_view(request):
    return render(request, 'login.html')


def register(request):
    return render(request, 'register.html')

def cart(request):
    return render(request, 'cart.html')

def staff_dashboard(request):
    return render(request, 'staff/dashboard.html')

def admin_dashboard(request):
    return render(request, 'admin_panel/dashboard.html')